import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:realm/realm.dart';

import '../../database/RealmDatabase.dart';
import '../../models/task.dart';
part 'tasks_event.dart';
part 'tasks_state.dart';
class TasksBloc extends Bloc<TasksEvent, TasksState> {
  RealmDatabase db = RealmDatabase();

  TasksBloc(this.db): super(TasksState(allTasks: db.getAllTask())) {
    on<AddTask>(_onAddTask);
    on<UpdateTask>(_onUpdateTask);
    on<DeleteTask>(_onDeleteTask);
    //on<RemoveTask>(_onRemoveTask);
  }

  void _onAddTask(AddTask event, Emitter<TasksState> emit) {
    var task = event.task;
    db.addTask(task);

    emit(TasksState(
      allTasks: db.getAllTask(),
    ));
  }

  void _onUpdateTask(UpdateTask event, Emitter<TasksState> emit) {
    final task = event.task;
    db.updateTask(task);
    emit(TasksState(
        allTasks: db.getAllTask(),
    ));
  }

  void _onDeleteTask(DeleteTask event, Emitter<TasksState> emit) {
    db.deleteTask(event.task);
    emit(TasksState(
      allTasks: db.getAllTask(),
    ));
  }

  // void _onRemoveTask(RemoveTask event, Emitter<TasksState> emit) {
  //   final state = this.state;
  //   emit(TasksState(
  //     allTasks: List.from(state.allTasks)..remove(event.task),
  //     removedTasks: List.from(state.removedTasks)
  //       ..add(event.task.copyWith(isDeleted: true)),
  //   ));
  // }
}