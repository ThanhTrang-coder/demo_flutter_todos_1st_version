part of 'tasks_bloc.dart';

class TasksState extends Equatable {
  // final List<Task> allTasks;
  // final List<Task> removedTasks;
  RealmResults<Task> allTasks;


  TasksState({
    required this.allTasks,
    // this.removedTasks = const <Task>[],
  });

  @override
  List<Object> get props => [allTasks];
}
